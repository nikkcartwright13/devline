self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/26485vhwuet28.js"
  ],
  "/404": [
    "static/chunks/1pz8zla0de4xt.js"
  ],
  "/_error": [
    "static/chunks/3psi33lik2ovd.js"
  ],
  "/company": [
    "static/chunks/2eqqj6tuhphpi.js"
  ],
  "/contact": [
    "static/chunks/3qub-fvuxejf4.js"
  ],
  "/de": [
    "static/chunks/1l2447qkqphgt.js"
  ],
  "/de/company": [
    "static/chunks/35w81-khs0ke7.js"
  ],
  "/de/contact": [
    "static/chunks/0dkjcy9uss8s-.js"
  ],
  "/de/mobile": [
    "static/chunks/2wdw4duw0e7hw.js"
  ],
  "/de/our-projects": [
    "static/chunks/2frx9s0oezj-j.js"
  ],
  "/de/services": [
    "static/chunks/2thpg81gy-oii.js"
  ],
  "/de/services/[slug]": [
    "static/chunks/1jy7tr_3gmows.js"
  ],
  "/en": [
    "static/chunks/0emartba7wje0.js"
  ],
  "/en/company": [
    "static/chunks/3i0i6wurv1exx.js"
  ],
  "/en/contact": [
    "static/chunks/1lcq_koq-rym1.js"
  ],
  "/en/mobile": [
    "static/chunks/3yf-nw6pkn8uz.js"
  ],
  "/en/our-projects": [
    "static/chunks/1-407x415f30n.js"
  ],
  "/en/services": [
    "static/chunks/269_pif3xzyl0.js"
  ],
  "/en/services/[slug]": [
    "static/chunks/1gj7bmrr3o84-.js"
  ],
  "/mobile": [
    "static/chunks/2v9fomyl-0k3c.js"
  ],
  "/our-projects": [
    "static/chunks/0sf6nl50i1h7h.js"
  ],
  "/pl": [
    "static/chunks/0qw_vl1407z5o.js"
  ],
  "/pl/company": [
    "static/chunks/3nthuh4bt6s9-.js"
  ],
  "/pl/contact": [
    "static/chunks/2pac-3g7vnsoz.js"
  ],
  "/pl/mobile": [
    "static/chunks/0p-phukh7gqw8.js"
  ],
  "/pl/our-projects": [
    "static/chunks/0y5gamad-bew8.js"
  ],
  "/pl/services": [
    "static/chunks/3-z_4jtyr3-df.js"
  ],
  "/pl/services/[slug]": [
    "static/chunks/1tifhlzio4wxk.js"
  ],
  "/services": [
    "static/chunks/3zurxba_fro-m.js"
  ],
  "/services/[slug]": [
    "static/chunks/0p806_2xdor67.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/404",
    "/_app",
    "/_error",
    "/company",
    "/contact",
    "/de",
    "/de/company",
    "/de/contact",
    "/de/mobile",
    "/de/our-projects",
    "/de/services",
    "/de/services/[slug]",
    "/en",
    "/en/company",
    "/en/contact",
    "/en/mobile",
    "/en/our-projects",
    "/en/services",
    "/en/services/[slug]",
    "/mobile",
    "/our-projects",
    "/pl",
    "/pl/company",
    "/pl/contact",
    "/pl/mobile",
    "/pl/our-projects",
    "/pl/services",
    "/pl/services/[slug]",
    "/services",
    "/services/[slug]"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()