__turbopack_load_page_chunks__("/404", [
  "static/chunks/02arnpc9ap97i.js",
  "static/chunks/1_o0achnslxv6.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-0lu3imyk_fuec.js"
])
