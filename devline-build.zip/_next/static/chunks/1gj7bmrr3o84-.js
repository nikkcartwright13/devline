__turbopack_load_page_chunks__("/en/services/[slug]", [
  "static/chunks/22foevqtm5xbt.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/turbopack-0f1mqtyi7_es9.js"
])
