__turbopack_load_page_chunks__("/de/company", [
  "static/chunks/2n3gu3zc8-o5e.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-1o2mrb6qmyr-c.js"
])
