__turbopack_load_page_chunks__("/pl/contact", [
  "static/chunks/2-rb4m0jugl_x.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-3q066qr89c7tl.js"
])
