__turbopack_load_page_chunks__("/_error", [
  "static/chunks/31s3zsdyb9m_g.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/turbopack-09__xjl-7ytst.js"
])
