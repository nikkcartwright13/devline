__turbopack_load_page_chunks__("/en/mobile", [
  "static/chunks/28psafzxx-eyt.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-2sqkbkyv5j710.js"
])
