__turbopack_load_page_chunks__("/_app", [
  "static/chunks/2f83vr_lxjyjr.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/2dyfsj-ve9o14.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/18ckp-zjhvqas.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/3zuc5wiwch4l4.css",
  "static/chunks/turbopack-21yxt313vvlyg.js"
])
