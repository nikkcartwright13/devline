__turbopack_load_page_chunks__("/en/contact", [
  "static/chunks/4160p-43d4yka.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-23bksbapaqax5.js"
])
