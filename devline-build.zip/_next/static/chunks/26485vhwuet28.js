__turbopack_load_page_chunks__("/", [
  "static/chunks/01pis94maiiol.js",
  "static/chunks/35u8pq4je5s-p.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/turbopack-2a_i8ucmq4hck.js"
])
