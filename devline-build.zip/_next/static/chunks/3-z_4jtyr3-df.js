__turbopack_load_page_chunks__("/pl/services", [
  "static/chunks/0681x2rhh1586.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/0z_1l_9-m5xhh.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/turbopack-0zu7-a2gs55uq.js"
])
