__turbopack_load_page_chunks__("/de/services/[slug]", [
  "static/chunks/2cw2696-12p4g.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/turbopack-1-c1y11ikw--j.js"
])
