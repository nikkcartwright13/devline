__turbopack_load_page_chunks__("/pl/our-projects", [
  "static/chunks/1u_lw-usv01ll.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-1gcpdmthu93qs.js"
])
