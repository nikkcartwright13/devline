__turbopack_load_page_chunks__("/services/[slug]", [
  "static/chunks/0n3thm4n5xwu4.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/turbopack-05ekg2j9vpb15.js"
])
