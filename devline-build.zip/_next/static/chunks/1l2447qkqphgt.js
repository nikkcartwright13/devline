__turbopack_load_page_chunks__("/de", [
  "static/chunks/1vi_bpnlqr0ft.js",
  "static/chunks/35u8pq4je5s-p.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/turbopack-2ac63w8isghr-.js"
])
