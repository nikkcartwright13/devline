__turbopack_load_page_chunks__("/de/services", [
  "static/chunks/329jkc1hl_caz.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/0z_1l_9-m5xhh.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/turbopack-06h23h4ivu9io.js"
])
