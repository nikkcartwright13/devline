__turbopack_load_page_chunks__("/mobile", [
  "static/chunks/21b5pc55wii4t.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-24tszn5ny13s2.js"
])
