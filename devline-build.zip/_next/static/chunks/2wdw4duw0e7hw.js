__turbopack_load_page_chunks__("/de/mobile", [
  "static/chunks/32nf0-5t09ok7.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-2ynefsoi-8waq.js"
])
