__turbopack_load_page_chunks__("/pl/company", [
  "static/chunks/31qnlur21k2qi.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-2ho4n69tlr_4s.js"
])
