__turbopack_load_page_chunks__("/de/our-projects", [
  "static/chunks/19u1b-ejx1ism.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-3tzcwaylq6es_.js"
])
