__turbopack_load_page_chunks__("/en/services", [
  "static/chunks/2o7k2r4p1u_06.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/0z_1l_9-m5xhh.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/turbopack-2exd-d75q9bb9.js"
])
