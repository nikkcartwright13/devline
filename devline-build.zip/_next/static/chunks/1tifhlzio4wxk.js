__turbopack_load_page_chunks__("/pl/services/[slug]", [
  "static/chunks/409rlgw1mdji-.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/turbopack-0d3f_scmrczin.js"
])
