__turbopack_load_page_chunks__("/company", [
  "static/chunks/1_vwfhd78tqj5.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-36euij8i_7ao5.js"
])
