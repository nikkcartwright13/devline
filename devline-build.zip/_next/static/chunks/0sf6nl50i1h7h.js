__turbopack_load_page_chunks__("/our-projects", [
  "static/chunks/33ubg6s0-pdaw.js",
  "static/chunks/3yy7uf73o6jt8.js",
  "static/chunks/04cnstflgytjn.js",
  "static/chunks/069t3m1hshupb.js",
  "static/chunks/08u2r6rsw9ct-.js",
  "static/chunks/turbopack-3975rdkrhnona.js"
])
